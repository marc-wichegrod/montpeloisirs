<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?
			SESSION_start();
		?>
		<?php
			include("include/header.php"); 
			include("include/nav.php");
			//$id=htmlspecialchars($_GET['id']);
			$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
			$rep = $bdd->query("select * from etablissement, type where id.type='1' and id.type=type.etablissement"); //-requete des bars parmi tous les etablissements
			while ($ligne = $rep ->fetch()){ 
				//echo "<a href='etablissements.php?id=".$ligne['id'].">".$ligne['map']."</a><br>\n";
				echo "<a href='etablissements.php?id=".$ligne['id']."'>".$ligne['nom']."</a><br>\n";
				echo "<a href='etablissements.php?id=".$ligne['id']."'>".$ligne['adresse']."</a><br>\n";
				echo "<a href='etablissements.php?id=".$ligne['id']."'>".$ligne['horaires']."</a><br>\n";
			}
			//$rep ->closeCursor();

			include("include/footer.php");
		?>
	</body>
	
</html>
