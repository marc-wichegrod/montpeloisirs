<html>

	<head>
		<meta charset="utf-8" />
		<title>Montpeloisirs</title>
		<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">

	</head>

	<body onload="onLoad();">
		<?
			SESSION_start();
		?>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		<?php
			$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
			if (!isset($_SESSION['utilisateur'])){
		?>
				
				 <p> Bienvenue sur Montpeloisirs, le premier site qui organise vos sorties selon votre personnalité ! </br>

				Comment ça fonctionne ? </p></br> 
				 <ul> 
				 <li>Vous savez où vous voulez aller? Indiquez simplement le nom de l’endroit souhaité dans la rubrique associée.</li> 

				 <li>Vous n’avez aucune idée de comment vous allez passer votre soirée ? Inscrivez-vous* puis choisissez l’onglet du questionnaire personnalisé. Il vous suffit de le remplir pour accéder aux propositions conseillées pour chaque catégorie d’établissement selon votre profil et votre localisation.</li> 
				 </ul> 
				 <p>*En vous inscrivant, vous remplirez un questionnaire personnalisé qui nous permettra de mieux vous connaître. Votre compte sera ouvert et vous pourrez avoir accès aux lieux fréquentés et à vos commentaires.</br>

				Montpeloisirs c’est aussi le partage d’avis et la possibilité de découvrir de nouveaux lieux grâce aux autres membres de la communauté.</br>

				À bientôt  </p> 
				 <img src="images/Montpellier.jpg"> 
				 <p> Pour effectuer une recherche personnalisée, vous pouvez : <br> 
				 <a href="inscription.php"/>Vous inscrire</a>	<a href="connexion.php">Vous identifier</a> 

				  <div id="map"></div>
		<script>// NE FONCTIONNE QU'AVEC UNE CONNEXION INTERNET 

			function initMap() {

			var map = new google.maps.Map(document.getElementById('map'), {
				zoom: 10,
				center: {lat: 43.62505, lng: 3.862038}
			});
			// Create an array of alphabetical characters used to label the markers.
			var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

			// Add some markers to the map.
			// Note: The code uses the JavaScript Array.prototype.map() method to
			// create an array of markers based on a given "locations" array.
			// The map() method here has nothing to do with the Google Maps API.
			var markers = locations.map(function(location, i) {
			  return new google.maps.Marker({
				position: location,
				label: labels[i % labels.length]
			  });
			});

			// var marqueur = new google.maps.Marker(markers);
			// var contenuInfoBulle='<h2>lala</h2>'+'<p>lala<p>';
			// var infoBulle = new google.maps.InfoWindow( {
				// content: contenuInfoBulle
			// })
			// google.maps.event.addListener(marqueur, 'click', function() {
				// infoBulle.open(location, marqueur);
			// });

			// Add a marker clusterer to manage the markers.
			 var markerCluster = new MarkerClusterer(map, markers,
				{imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
			}
		  var locations = [
		  <?
			$rep2 = $bdd->query('select * from etablissement');
			while ($ligne = $rep2 ->fetch()){
		  ?>
			{lat: <? echo $ligne['Y']; ?>, lng: <? echo $ligne['X']; ?>},
			<? }?>
			]

		</script>
		<script src="markerclusterer.js">
		</script>
		<script async defer
		src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAREO5_GOngQSjIqYOTCylPeNda4kOlXrA&callback=initMap">
		</script><br>

		<?
			}
			else{
				$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
				$rep3 = $bdd->query("select * from etablissement as e,utilisateur as u,preferer_type as t,preferer_ambiance as a,preferer_convives as c, type
										where u.id=t.id_utilisateur and  u.id=a.id_utilisateur and u.id=c.id_utilisateur and e.type=type.id and type.id=t.id");  // requete qui acffiche les etablissement qui ont l'ambiance 
			
			while ($ligne = $rep3 ->fetch()){ // recuperations des infos sur les bars
				echo "<fieldset>";
				echo "<a href='etablissement.php?id-eta=".$ligne['id-eta']."'>".$ligne['map']."</a>\n";
				echo "<a href='etablissement.php?id-eta=".$ligne['id_eta']."'>".$ligne['nom']."</a>\n";
				echo "<a href='etablissement.php?id-eta=".$ligne['id-eta']."'>".$ligne['adresse']."</a>\n";
				echo "<a href='etablissement.php?id-eta=".$ligne['id-eta']."'>".$ligne['horaires']."</a>\n";
				echo "</fieldset>";
				 }
			$rep ->closeCursor();
		}
		?>
		
		
		<?php
			include("include/footer.php");
		?>
		
	</body>
	
</html>