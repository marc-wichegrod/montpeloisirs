<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		
		<img src="" alt="Image établissement" width="35%" />

		<div id="infos_eta">
			<ul>
				<li>Nom</li>
				<li>Adresse</li>
				<li>Horaires</li>
				<li>Note</li>
				<li>Nombre de visites</li>
			</ul>
		</div>

		<div>
			<button onclick="openTab('descriptif')">Descriptif</button>
			<button onclick="openTab('photos')">Photos</button>
			<button onclick="openTab('avis')">Avis</button>
			<button onclick="openTab('map')">Map</button>
		</div>

		<div id="descriptif" class="tab">
			Descriptif établissement
		</div>


		<div id="photos" class="tab" style="display:none">
			Photos
		</div>

		<div id="avis" class="tab" style="display:none">
			Avis
		</div>

		<div id="map" class="tab" style="display:none">
			map établissement
		</div>

		
		<?php
			include("include/footer.php");
		?>
	
	<script type="text/javascript">
		function openTab(idTab)
		{
			var i;
			var x = document.getElementsByClassName("tab");
			for (var i = 0; i < x.length; i++)
			{
				x[i].style.display = "none";
			}
			document.getElementById(idTab).style.display = "block";
		}
	</script>

	</body>
	
</html>