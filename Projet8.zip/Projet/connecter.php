<?php
session_start()
?>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet"href="styles/style.css"type="text/css"media="screen"/>
		<title>Montpeloisirs</title>
	</head>
		<body>
		<?php
		
		$bdd = new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8','root','root');
		$req = "select * from user where 'pseudo' ='".$_GET['pseudo']."' and 'mdp' = '".$_GET['mdp']."'";
		$rep = $bdd->query($req);
		$ligne = $req->fetch();
		
	
		if(!$ligne) {
			echo "<META http-equiv='refresh' content='1; URL=connexion.php'>";
		}
		else{
			$_SESSION['client']=$ligne;
			echo "<META http-equiv='refresh' content='1; URL=index.php'>";
		}
		?>
		
		
		</body>
</html>