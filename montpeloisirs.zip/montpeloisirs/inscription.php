<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<p id="connexion">
			<a href=""> Identification</a> | 
			<a href="">Connexion</a> 
		</p>
		<?php
			include("include/header.php"); //Différence requise-once et include ?
			include("include/nav.php");
			//$id=htmlspecialchars($_GET['id']);
			$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
		?>
		<form method="GET" action="">
	
		<fieldset> <!--Permet de faire l'encadrer-->
			<input type=hidden name="id" value="<?php echo $id ?>">
			<legend>Qui êtes-vous ? </legend>
			<label for="Sexe">Sexe : </label>
			<input type="radio" value="Femme" name="Sexe"/> Femme
			<input type="radio" value="Homme" name="Sexe"/> Homme
			<br>
			<label for="prenom">Prenom :</label>
			<textarea name="prenom" rows="1"  cols="30" placeholder="Votre prenom"></textarea>
			<br/>	
			<label for="date_naissance">Date de naissance :</label>
			<select name="date_naissance" size="1">
				<option>01
				<option>02
				<option>03
				<option>04
				<option>05
				<option>06
				<option>07
				<option>08
				<option>09
				<option>10
				<option>11
				<option>12
				<option>13
				<option>14
				<option>15
				<option>16
				<option>17
				<option>18
				<option>19
				<option>20
				<option>21
				<option>22
				<option>23
				<option>24
				<option>25
				<option>26
				<option>27
				<option>28
				<option>29
				<option>30
				<option>31
			</select>
			<select name="date_naissance" size="1">
				<option>Janvier
				<option>Février
				<option>Mars
				<option>Avril
				<option>Mai
				<option>Juin
				<option>Juillet
				<option>Août
				<option>Septembre
				<option>Octobre
				<option>Novembre
				<option>Décembre
			</select>
			<select name="date_naissance" size="1">
				<option>	1940
				<option>	1941
				<option>	1942
				<option>	1943
				<option>	1944
				<option>	1945
				<option>	1946
				<option>	1947
				<option>	1948
				<option>	1949
				<option>	1950
				<option>	1951
				<option>	1952
				<option>	1953
				<option>	1954
				<option>	1955
				<option>	1956
				<option>	1957
				<option>	1958
				<option>	1959
				<option>	1960
				<option>	1961
				<option>	1962
				<option>	1963
				<option>	1964
				<option>	1965
				<option>	1966
				<option>	1967
				<option>	1968
				<option>	1969
				<option>	1970
				<option>	1971
				<option>	1972
				<option>	1973
				<option>	1974
				<option>	1975
				<option>	1976
				<option>	1977
				<option>	1978
				<option>	1979
				<option>	1980
				<option>	1981
				<option>	1982
				<option>	1983
				<option>	1984
				<option>	1985
				<option>	1986
				<option>	1987
				<option>	1988
				<option>	1989
				<option>	1990
				<option>	1991
				<option>	1992
				<option>	1993
				<option>	1994
				<option>	1995
				<option>	1996
				<option>	1997
				<option>	1998
				<option>	1999
				<option>	2000
				<option>	2001
				<option>	2002
				<option>	2003
				<option>	2004
				<option>	2005
				<option>	2006
				<option>	2007
				<option>	2008
				<option>	2009
				<option>	2010
			</select>
		</fieldset>
		
		<fieldset> <!--probleme de jointure avec la base-->
			<legend>Vos sorties ?</legend>
			<label for="">A quel fréquence sortez-vous ?</label>
			<input type="radio" value="toutletps" name="Sexe"/> Tout le temps
			<input type="radio" value="Regulierement" name="Sexe"/> Régulièrement
			<input type="radio" value="Rarement" name="Sexe"/> Rarement
			<br>
			<label for="age">Avec qui amez-vous sortir ?</label>
			<input  type="checkbox" name="Famille"/>
				<label for="Famille">En famille</label>
			<input  type="checkbox" name="Amis" />
				<label for="Amis">Entre amis</label>
			<input type="checkbox" name="Amoureux" />
				<label for="Amoureux">Entre amoureux</label>
		</fieldset>
		<p>
			<input type="submit" value="Confirmation de votre inscription">
		</p>
		
		<a href="index.php"> Accueil</a>
		<?php
			include("include/footer.php");
		?>
	
	</body>
	
</html>