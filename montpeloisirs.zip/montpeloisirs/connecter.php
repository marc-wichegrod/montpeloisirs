<?php
session_start()
?>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet"href="styles/style.css"type="text/css"media="screen"/>
		<title>Montpeloisirs</title>
	</head>
		<body>
		<?php
		
		$bdd = new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8','root','root');
		$req = "select * from user where 'pseudo' ='".$_GET['pseudo']."' and 'mdp' = '".$_GET['mdp']."'";
		$rep = $bdd->query($req);
		$ligne = $req->fetch();
		
	
		if( $_GET['pseudo']=="" || $_GET['mdp']=="" || $_GET['pseudo'] != $ligne['pseudo']  || $_GET['mdp'] != $ligne['mdp']) {
			echo "<META http-equiv='refresh' content='1; URL=connexion.php'>";
		}
		else{
			$_SESSION['user']=array();
			$_SESSION['user']['id']=$ligne['id-user'];
			$_SESSION['user']['email']=$ligne['email'];
			$_SESSION['user']['pseudo']='$_GET['pseudo']';
			$_SESSION['user']['mdp']='$_GET['mdp']';
			echo "<META http-equiv='refresh' content='1; URL=index.php'>";
		}
		?>
		
		
		</body>
</html>