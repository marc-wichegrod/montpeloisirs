<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet"href="styles/style.css"type="text/css"media="screen"/>
		<title>Montpeloisirs</title>
	</head>
		<body>
		<?php
			session_start();
			session_destroy();
		?>
		
		<a href="index.php" > retour</a>
		</body>
</html>