<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
	<p id="Identification">
			<a href="inscription.php">Identification</a> 
			<a href="connexion.php">Connexion</a> 
		</p>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		<?php
		
		
		$bdd = new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8','root','root');
		$req ='select * from etablissement where "nom" LIKE %"'.$_GET['nom'].'"';
		$rep = $bdd->query($req);
		$ligne = $req->fetch();
		
	
		if( $_GET['nom']=="" ) {
		  echo "<META http-equiv='refresh' content='0; URL=index.php'>"; 
		}
		else{
			while ($ligne = $rep ->fetch()) { 
			echo "<fieldset>";
			echo "<tr>\n";
			echo "<td>";
			echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['map']."</a></td>\n";
			echo "<td>";
			echo "a href='etablissements.php?id-eta=".$ligne['id_eta']."'>".$ligne['nom']."</a></td>\n";
			echo "<td>";
			echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['adresse']."</a></td>\n";
			echo "<td>";
			echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['horaires']."</a></td>\n";
			echo "</fieldset>";
		}
		$rep ->closeCursor();
			
			
		}		
		?>	
	<a href="index.php> Accueuil </a>
	
	
	
	
	</body>
</head>