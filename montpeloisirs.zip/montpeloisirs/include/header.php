<div id="entete">
		<a href="index.php"><img src="images/logoF.png">
		<h1><a href="index.php">Montpeloisirs<a></h1>
</div>

	