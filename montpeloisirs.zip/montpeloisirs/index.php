<?php
session_start()
?>

<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
			<p id="connexion">
			<a href="inscription.php">Inscription</a> | 
			<a href="connexion.php">Connexion</a> 
		</p>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		<p> Bienvenue sur Montpeloisirs, le premier site qui organise vos sorties selon votre personnalité ! </br>

Comment ça fonctionne ? </p></br>
<ul>
<li>Vous savez où vous voulez aller? Indiquez simplement le nom de l’endroit souhaité dans la rubrique associée.</li>

<li>Vous n’avez aucune idée de comment vous allez passer votre soirée ? Inscrivez-vous* puis choisissez l’onglet du questionnaire personnalisé. Il vous suffit de le remplir pour accéder aux propositions conseillées pour chaque catégorie d’établissement selon votre profil et votre localisation.</li>
</ul>
<p>*En vous inscrivant, vous remplirez un questionnaire personnalisé qui nous permettra de mieux vous connaître. Votre compte sera ouvert et vous pourrez avoir accès aux lieux fréquentés et à vos commentaires.</br>

Montpeloisirs c’est aussi le partage d’avis et la possibilité de découvrir de nouveaux lieux grâce aux autres membres de la communauté.</br>

À bientôt  </p>
		<img src="images/Montpellier.jpg">
		<p> Pour effectuer une recherche personnalisée, vous pouvez : <br>
		<a href="inscription.php">Vous inscrire</a>	<a href="connexion.php">Vous identifier</a>
		
		<p id="map">MAP</p>
		
		
		<?php
			include("include/footer.php");
		?>
	
	</body>
	
</html>