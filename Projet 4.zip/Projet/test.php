<?php
$adresse = "https://www.tripadvisor.fr/Restaurant_Review-g187153-d8036149-Reviews-Le_Pat_Daniel_s-Montpellier_Herault_Occitanie.html"; // adresse de la page à exploiter
echo "$adresse <br>"; // afficher l'adresse
$page = file_get_contents ($adresse); // récupérer le contenu de la page
echo $page ; // afficher la page
?>