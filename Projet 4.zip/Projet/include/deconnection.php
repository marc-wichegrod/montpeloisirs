<?
SESSION_start();
SESSION_destroy();
echo'<meta http-equiv="Refresh" content="0; url=../index.php" />';
?>