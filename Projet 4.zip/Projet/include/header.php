<?
SESSION_start();
?>
<p id="connexion">
<?
	if(!isset($_SESSION['client'])){		
		echo"<a href='inscription.php'>Inscription</a> |"; 
		echo"<a href='connexion.php'>Connexion</a>";
	}
	else{ 
		echo"<a href='deconnection.php'>Déconnection</a>";
	}
?>
</p>
<div id="entete">
		<a href="index.php"><img src="images/logoF.png">
		<h1><a href="index.php">Montpeloisirs<a></h1>
</div>

	