<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<link rel="stylesheet" href="styles/style.css" type="text/css" media="screen" />
	<link rel="icon" type="image/jpg" href="images/favicon.png" />
	<title>Handegg shop</title>
	<?php
		require 'classe/user.class.php';

		if ($_GET['id']=="" || $_GET['sexe']=="" || $_GET['jour_naissance']=="" || $_GET['mois_naissance']=="" || $_GET['annee_naissance']=="" || || $_GET['email']=="" || $_GET['pseudo']=="" || $_GET['mdp']=="" $_GET['mdp_conf']=="")
		{
			echo "<meta http-equiv='Refresh' content='0;url=inscription.php?erreur=info_manquante&id=".$_GET['id']."&sexe=".$_GET['sexe']."&jour_naissance=".$_GET['jour_naissance']."&mois_naissance=".$_GET['mois_naissance']."&annee_naissance=".$_GET['annee_naissance']."&email=".$_GET['email']."&pseudo=".$_GET['pseudo'].">";
		}

		elseif ($_GET['mdp'] != $_GET['mdp_conf']) {
			echo "<meta http-equiv='Refresh' content='0;url=inscription.php?erreur=mdp&id=".$_GET['id']."&sexe=".$_GET['sexe']."&jour_naissance=".$_GET['jour_naissance']."&mois_naissance=".$_GET['mois_naissance']."&annee_naissance=".$_GET['annee_naissance']."&email=".$_GET['email']."&pseudo=".$_GET['pseudo'].">";

		else
		{
			enregistrer($_GET['n'], $_GET['p'], $_GET['adr'], $_GET['mail'], $_GET['num'], $_GET['mdp']);
			echo'<meta http-equiv="Refresh" content="0;url=index.php">';
		} 

	?>	 
</head>
<body>
	<a href=index.php>Retour index</a>
	<a href="contact/contact.html" id="">Contact</a>
</body>
</html> 