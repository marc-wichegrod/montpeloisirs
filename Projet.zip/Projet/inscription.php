<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>	
		<?php
			include("include/header.php");
			include("include/nav.php");
			// $id=htmlspecialchars($_GET['id']);
			// $bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
		?>
		<form id="form" method="get" action="enregistrement.php">
	
		<fieldset> <!--Permet de faire l'encadré-->
			<legend>Qui êtes-vous ?</legend>
			<label for="sexe">Sexe : </label>
			<input type="radio" value="femme" name="sexe" <?php if (isset($_GET['sexe']) && $_GET['sexe'] == "femme") { echo "checked='true'"; } ?> /> Femme
			<input type="radio" value="homme" name="sexe" <?php if (isset($_GET['sexe']) && $_GET['sexe'] == "homme") { echo "checked='true'"; } ?> /> Homme
			<br/><br/>
			<label for="date_naissance">Date de naissance :</label>
			<input type="date" name="date_naissance" <?php if (isset($_GET['date_naissance'])) { echo "value='".$_GET['date_naissance']."'"; } ?> >
		</fieldset>
		
		<fieldset>
			<legend>Informations de compte</legend>

			<label for="email">E-mail : </label>
			<input type="text" name="email" <?php if (isset($_GET['email'])) { echo "value='".$_GET['email']."'"; } ?> /> <br/><br/>
			<label for="pseudo">Pseudo : </label>
			<input type="text" name="pseudo" <?php if (isset($_GET['pseudo'])) { echo "value='".$_GET['pseudo']."'"; } ?> /> <br/><br/>
			<label for="mdp">Mot de passe : </label>
			<input type="text" name="mdp" /> <br/><br/>
			<label for="mdp_conf">Confirmation du mot de passe : </label>
			<input type="text" name="mdp_conf" />
			<span type="span" style="color: red;">
				<?php if (isset($_GET['erreur']) && $_GET['erreur'] == "mdp") {echo "Les mots de passe doivent correspondre";} ?>
			</span>
		</fieldset>


		<fieldset> <!--probleme de jointure avec la base-->
			<legend>Vos sorties ?</legend>
			<label for="frequence">A quelle fréquence sortez-vous ?</label>
			<input type="radio" value="1" name="frequence" <?php if (isset($_GET['frequence']) && $_GET['frequence'] == "1") { echo "checked='true'"; } ?> /> Tout le temps
			<input type="radio" value="2" name="frequence" <?php if (isset($_GET['frequence']) && $_GET['frequence'] == "2") { echo "checked='true'"; } ?> /> Régulièrement
			<input type="radio" value="3" name="frequence" <?php if (isset($_GET['frequence']) && $_GET['frequence'] == "3") { echo "checked='true'"; } ?> /> Rarement
			<br/><br/>
			<label>Avec qui aimez-vous sortir ?</label>
			<input type="radio" value="1" name="convives" <?php if (isset($_GET['convives']) && $_GET['convives'] == "1") { echo "checked='true'"; } ?> /> En famille
			<input type="radio" value="2" name="convives" <?php if (isset($_GET['convives']) && $_GET['convives'] == "2") { echo "checked='true'"; } ?> /> Entre amis
			<input type="radio" value="3" name="convives" <?php if (isset($_GET['convives']) && $_GET['convives'] == "3") { echo "checked='true'"; } ?> /> Entre amoureux
			<br/><br/>
			<label>Quel(s) type(s) de lieu préférez-vous ?</label>
			<input type="radio" value="1" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "1") { echo "checked='true'"; } ?> /> Bar
			<input type="radio" value="2" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "2") { echo "checked='true'"; } ?> /> Café
			<input type="radio" value="3" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "3") { echo "checked='true'"; } ?> /> Fast-food
			<input type="radio" value="5" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "4") { echo "checked='true'"; } ?> /> Pub <br><br>
			<input type="radio" value="6" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "5") { echo "checked='true'"; } ?> /> Restaurant
			<input type="radio" value="7" name="lieu" <?php if (isset($_GET['lieu']) && $_GET['lieu'] == "6") { echo "checked='true'"; } ?> /> Cinéma
			<br/><br/>
			<label>Quel type d'ambiance préférez-vous ?</label>
			<input type="radio" value="1" name="ambiance" <?php if (isset($_GET['ambiance']) && $_GET['ambiance'] == "1") { echo "checked='true'"; } ?> /> Electro
			<input type="radio" value="2" name="ambiance" <?php if (isset($_GET['ambiance']) && $_GET['ambiance'] == "2") { echo "checked='true'"; } ?> /> Chic
			<input type="radio" value="3" name="ambiance" <?php if (isset($_GET['ambiance']) && $_GET['ambiance'] == "3") { echo "checked='true'"; } ?> //> Dansante <br/><br/>
			<input type="radio" value="4" name="ambiance" <?php if (isset($_GET['ambiance']) && $_GET['ambiance'] == "4") { echo "checked='true'"; } ?> //> Multiculturelle
			<input type="radio" value="5" name="ambiance" <?php if (isset($_GET['ambiance']) && $_GET['ambiance'] == "5") { echo "checked='true'"; } ?> //> Rétro
			<br/><br/>
		</fieldset>
		<p>
			<input type="submit" value="Confirmer votre inscription">
		</p>

		</form>
		
		
		<?php
			include("include/footer.php");
		?>

	</body>
	
</html>