<?php
class User
{
    private $id_user;
    private $pseudo;
    private $email;
    private $mdp ;
    public function __construct($id,$pseudo,$email,$mdp)
    {
            $this-> id_user= $id;
            $this-> pseudo = $pseudo;
            $this-> email = $email ;
            $this-> mdp = $mdp ;
    }
    public function __destruct()
    {

    }
    public function __get($attribut)
    {
        switch ($attribut)
        {
                case'id_user': {return $this->id_user; }
                case'pseudo':{return $this->pseudo; }
                case'email':{return $this->email; }
                case'mdp':{return $this->mdp; }
        }
    }

    public function __set($attribut,$nouvelleValeur)
    {
        switch ($attribut)
        {
            case'id_user': { $this->id_user = $nouvelleValeur; break; }
            case'pseudo':{ $this->pseudo = $nouvelleValeur; break; }
            case'email':{ $this->email = $nouvelleValeur; break; }
            case'mdp':{ $this->mdp = $nouvelleValeur; break; }
        }

    }

   
    static public function recherche($id)
    {
        require '../include/connect.php';
        try
        {
                // permet de retourner un objet user dont id_user=$id
                $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

                $req = $bdd->prepare("select * FROM user where id_user = ?");
                $req->execute(array($num));
                $reponse = $req->fetch();
                $user = new user($reponse[0], $reponse[1], $reponse[2], $reponse[3]);
                
                return $user; // On retourne la revue
            }
            
            catch (Exception $e)
        {
            die('Erreur : ' . $e->getMessage());
        }
    
    }

    function enregistrer()
    {
        require "include/connect.php";

        $req = $bdd->exec("INSERT INTO user (pseudo, email, mdp)
                            VALUES('".$this->pseudo."', '".$this->email."', '".$this->mdp."')");
    }
    
    
    public function __toString() // function magique qui s'utilisera avec print( $user) ou echo $user
    {
            return $this->id.";". $this->pseudo .";". $this->email .";".$this->mdp;
    }
}     
?>
