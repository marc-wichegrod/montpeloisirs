<?php
$host = "localhost";
$util = "root";
$password = "root";
$bdd = "montpeloisirs";
$bdd = new PDO('mysql:host='.$host.';dbname='.$bdd, $util, $password, $pdo_options);
?>