<div id="entete">
		<h1><a href="index.php"><img src="images/logo.jpg">Montpeloisirs<a></h1>
</div>

	