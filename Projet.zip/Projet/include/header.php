<div id="entete">
	<img src="Logo.jpg" href="index.php">
	<h1>Montpeloisirs</h1>
</div>

	