<ul>
	<li>34 Route de Mende, 34090 Montpellie</li>
	<li>06 22 73 71 48</li>
	<li>contact@montpeloisirs.fr</li>
	<li>logo facebook, twitter, insta, github</li>
</ul>
	
	