<div>
	<ul>
		<li><a href="">Bar<a></li>
		<li><a href="">Restaurant<a></li> 
		<li><a href="">Cinéma<a></li>
		<li><a href="">Recherche personnalisée<a></li> 
	</ul>
</div>

