<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?php
			SESSION_start();

			include("include/header.php"); 
			include("include/nav.php");
			//$id=htmlspecialchars($_GET['id']);
			$bdd = new PDO('mysql:host=localhost:3306;dbname=montpeloisirs;charset=utf8', 'root', 'root');
			$rep = $bdd->query("select * from etablissement where type = 6"); //requete des bars parmi tous les etablissements
		?>

		<table>
			<tr>
				<th>Nom</th>
				<th>Téléphone</th>
				<th>Site web</th>
				<th>Description</th>
				<th>Accès PMR</th>
			</tr>
		

		<?php

			while ($eta = $rep ->fetch()){
				$dispo = false;
				echo "<tr>";


				$url = $eta['site_web'];
				//echo "<a href='etablissements.php?id=".$eta['id'].">".$eta['map']."</a><br>\n";
				if (strpos($url, 'http://') !== false) {
					$url = "//".substr($url, 7);
				}
				else
					$url = "//".$url;
				echo "<td>".$eta['nom']."</td>";
				echo "<td>".$eta['telephone']."</td>";
				if ($url != "//Non renseigné")
					echo "<td><a href='".$url."' target='_blank'>".substr($url, 2)."</a></td>";
				else
					echo "<td>Non renseigné</td>";
				echo "<td>".$eta['description']."</td>";
				echo "<td>".$eta['acces_pmr'].$dispo."</td>";
				
				echo "</tr>";
			}
			//$rep ->closeCursor();

		?>

		
		</table>

		<?php
			include("include/footer.php");
		?>
	</body>
	
</html>
