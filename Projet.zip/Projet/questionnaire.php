<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?php
			include("include/header.php");
			include("include/nav.php");
			// $id=htmlspecialchars($_GET['id']);
			// $bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
		?>
		<form method="GET" action="resultat.php">

		<fieldset>
			<label>Quel(s) type(s) de lieu préférez-vous ?</label>
			<input type="radio" value="1" name="lieu" /> Bar
			<input type="radio" value="2" name="lieu" /> Café
			<input type="radio" value="3" name="lieu" /> Fast-food
			<input type="radio" value="5" name="lieu" /> Pub <br><br>
			<input type="radio" value="6" name="lieu" /> Restaurant
			<input type="radio" value="7" name="lieu" /> Cinéma
			<br/><br/>
			<label>Quel type d'ambiance préférez-vous ?</label>
			<input type="radio" value="1" name="ambiance" /> Electro
			<input type="radio" value="2" name="ambiance" /> Chic
			<input type="radio" value="3" name="ambiance" /> Dansante <br/><br/>
			<input type="radio" value="4" name="ambiance" /> Multiculturelle
			<input type="radio" value="5" name="ambiance" /> Rétro
			<br/><br/>
		</fieldset>
		<p>
			<input type="submit" value="Rechercher">
		</p>
		
		
		<?php
			include("include/footer.php");
		?>
	
	</body>
	
</html>