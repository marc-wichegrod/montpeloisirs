<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<p id="connexion">
			<a href="">Identification</a> | 
			<a href="inscription.php">Connexion</a> 
		</p>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		<p> Presentation du site avec une belle petite photo </p>
		<p> Pour effectuer une recherche personnalisée, vous pouvez : <br>
		<a href="">Vous inscrire</a>	<a href="">Vous identifier</a>
		
		<p id="map">MAP</p>
		
		<?php
			include("include/footer.php");
		?>
	
	</body>
	
</html>