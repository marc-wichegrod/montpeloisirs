<div id="menu">
	<ul>
		<li><a href="">Bar<a></li>
		<li><a href="">Restaurant<a></li> 
		<li><a href="">Cinéma<a></li>
		<li><a href="questionnaire.php">Recherche personnalisée<a></li> 
	</ul>
</div>

