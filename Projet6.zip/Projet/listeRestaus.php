<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?
			// SESSION_start();
		// ?>
		<?
			// include("include/header.php"); 
			// include("include/nav.php");
			// $bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
			// $rep = $bdd->query("select * from restaurant"); //<!--requete des resto parmi tous les etablissements-->
			
		// while ($ligne = $rep ->fetch()) { // recuperations des infos sur les bars
			// echo "<fieldset>";
			// echo "<tr>\n";
			// echo "<td>";
			// echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['map']."</a></td>\n";
			// echo "<td>";
			// echo "a href='etablissements.php?id-eta=".$ligne['id_eta']."'>".$ligne['nom']."</a></td>\n";
			// echo "<td>";
			// echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['adresse']."</a></td>\n";
			// echo "<td>";
			// echo "a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['horaires']."</a></td>\n";
			// echo "</fieldset>";
		// }
		// $rep ->closeCursor();

			// include("include/footer.php");
		// ?>
	<a href="index">Accueil</a>
	</body>
	
</html>