<div id="menu">
	<ul>
		<li><a href="listeBars.php">Bar</a></li>
		<li><a href="">Restaurant</a></li> 
		<li><a href="test.php">Cinéma</a></li>
		<li><a href="questionnaire.php">Recherche personnalisée</a></li> 
	</ul>
</div>

