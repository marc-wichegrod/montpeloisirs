<?php
class Utilisateur
{
    private $id;
    private $sexe;
    private $date_naissance;
    private $email;
    private $pseudo;
    private $mdp;
    private $frequence;
    public function __construct($id,$sexe,$date_naissance,$email,$pseudo,$mdp, $frequence)
    {
            $this-> id= $id;
            $this-> sexe = $sexe;
            $this-> date_naissance = $date_naissance;
            $this-> email = $email ;
            $this-> pseudo = $pseudo;
            $this-> mdp = $mdp ;
            $this-> frequence = $frequence ;
    }
    public function __destruct()
    {

    }
    public function __get($attribut)
    {
        switch ($attribut)
        {
                case'id': {return $this->id; }
                case'sexe':{return $this->sexe; }
                case'date_naissance':{return $this->date_naissance; }
                case'email':{return $this->email; }
                case'pseudo':{return $this->pseudo; }
                case'mdp':{return $this->mdp; }
                case'frequence':{return $this->frequence; }
        }
    }

    public function __set($attribut,$nouvelleValeur)
    {
        switch ($attribut)
        {
            case'id': { $this->id = $nouvelleValeur; break; }
            case'sexe':{ $this->sexe = $nouvelleValeur; break; }
            case'date_naissance':{ $this->date_naissance = $nouvelleValeur; break; }
            case'email':{ $this->email = $nouvelleValeur; break; }
            case'pseudo':{ $this->pseudo = $nouvelleValeur; break; }
            case'mdp':{ $this->mdp = $nouvelleValeur; break; }
            case'frequence':{ $this->frequence = $nouvelleValeur; break; }
        }

    }

   
    static public function rechercheParId($id)
    {
        require '../include/connect.php';
        echo "string";
        try
        {
                // permet de retourner un objet user dont id_user=$id
                $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

                $req = $bdd->prepare("select * FROM usilisateur where id = ?");
                $req->execute(array($id));
                $reponse = $req->fetch();
                $utilisateur = new user($reponse[0], $reponse[1], $reponse[2], $reponse[3], $reponse[4], $reponse[5], $reponse[6]);
                
                return $utilisateur; // On retourne l'utilisateur
            }
            
            catch (Exception $e)
        {
            die('Erreur : ' . $e->getMessage());
        }
    
    }

    static public function rechercheIdParEmail($email)
    {
        require "include/connect.php";
        try
        {
            // permet de retourner un objet user dont email=$email
            $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

            $req = $bdd->query("select * FROM utilisateur where email = '".$email."'");

            $reponse = $req->fetch();
            $id = $reponse[0];
            return $id; // On retourne l'ID
        }
        catch (Exception $e)
        {
            die('Erreur : ' . $e->getMessage());
        }
    
    }

    function enregistrer($id_type, $id_ambiance, $id_convives)
    {
        require "include/connect.php";

        $erreur = "0";

        $req_existe = $bdd->query("SELECT id FROM utilisateur WHERE email = '".$this->email."'");
        $existe = $req_existe->fetch();
        
        if ($existe == null) {
            $req = $bdd->exec("INSERT INTO utilisateur (sexe, date_naissance, email, pseudo, mdp, id_frequence)
                        VALUES('".$this->sexe."', '".$this->date_naissance."', '".$this->email."', '".$this->pseudo."', '".$this->mdp."', '".$this->frequence."')");
            $id_utilisateur = self::rechercheIdParEmail($this->email);
            if($id_type != null)
                $req_type = $bdd->exec("INSERT INTO preferer_type VALUES (".$id_type.", ".$id_utilisateur.")");
            if($id_ambiance != null)
                $req_ambiance = $bdd->exec("INSERT INTO preferer_ambiance VALUES (".$id_ambiance.", ".$id_utilisateur.")");
            if($id_convives != null)
                $req_convives = $bdd->exec("INSERT INTO preferer_convives VALUES (".$id_convives.", ".$id_utilisateur.")");

        }
        else
            $erreur = "Adresse déjà utilisée";
        

        return $erreur;
    }
    
}

?>
