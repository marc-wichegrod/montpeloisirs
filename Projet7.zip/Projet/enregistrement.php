<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<link rel="stylesheet" href="style/style.css" type="text/css" media="screen" />
	<link rel="icon" type="image/jpg" href="images/favicon.png" />
	<title>Montpeloisirs</title>
	<?php
		require 'classe/utilisateur.class.php';

		if ($_GET['sexe']=="" || $_GET['date_naissance']=="" || $_GET['email']=="" || $_GET['pseudo']=="" || $_GET['mdp']=="" || $_GET['mdp_conf']=="")
		{
			echo "<meta http-equiv='Refresh' content='0;url=inscription.php?erreur=info_manquante&sexe=".$_GET['sexe']."&date_naissance=".$_GET['date_naissance']."&email=".$_GET['email']."&pseudo=".$_GET['pseudo']."'>";
		}

		elseif ($_GET['mdp'] != $_GET['mdp_conf']) {
			echo "<meta http-equiv='Refresh' content='0;url=inscription.php?erreur=mdp&sexe=".$_GET['sexe']."&date_naissance=".$_GET['date_naissance']."&email=".$_GET['email']."&pseudo=".$_GET['pseudo']."'>";
		}

		else
		{
			$utilisateur = new utilisateur(null, $_GET['sexe'], $_GET['date_naissance'], $_GET['email'], $_GET['pseudo'], $_GET['mdp'], $_GET['frequence']);
			if (isset($_GET['lieu']) || isset($_GET['ambiance']) || isset($_GET['convives'])) {
				$regist = $utilisateur->enregistrer($_GET['lieu'], $_GET['ambiance'], $_GET['convives']);

				if ($regist != "0") {
					echo "<meta http-equiv='Refresh' content='0;url=inscription.php?erreur=email_existant&sexe=".$_GET['sexe']."&date_naissance=".$_GET['date_naissance']."&email=".$_GET['email']."&pseudo=".$_GET['pseudo']."'>";

				}
			}
			//echo'<meta http-equiv="Refresh" content="0;url=index.php">';
		} 

	?>	 
</head>
<body>
</body>
</html> 