<?php
session_start()
?>

<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<?php
			include("include/header.php");
			include("include/nav.php");
		?>
		<?php
			if (!isset($_SESSION['utilisateur'])){
				
				echo '<p id="connexion">';
				echo '<a href="inscription.php">Inscription</a>'; 
				echo '<a href="connexion.php">Connexion</a>'; 
				echo '</p>';
				echo '<p> Bienvenue sur Montpeloisirs, le premier site qui organise vos sorties selon votre personnalité ! </br>

				Comment ça fonctionne ? </p></br>';
				echo'<ul>';
				echo'<li>Vous savez où vous voulez aller? Indiquez simplement le nom de l’endroit souhaité dans la rubrique associée.</li>';

				echo'<li>Vous n’avez aucune idée de comment vous allez passer votre soirée ? Inscrivez-vous* puis choisissez l’onglet du questionnaire personnalisé. Il vous suffit de le remplir pour accéder aux propositions conseillées pour chaque catégorie d’établissement selon votre profil et votre localisation.</li>';
				echo'</ul>';
				echo'<p>*En vous inscrivant, vous remplirez un questionnaire personnalisé qui nous permettra de mieux vous connaître. Votre compte sera ouvert et vous pourrez avoir accès aux lieux fréquentés et à vos commentaires.</br>

				Montpeloisirs c’est aussi le partage d’avis et la possibilité de découvrir de nouveaux lieux grâce aux autres membres de la communauté.</br>

				À bientôt  </p>';
				echo'<img src="images/Montpellier.jpg">';
				echo'<p> Pour effectuer une recherche personnalisée, vous pouvez : <br>';
				echo'<a href="inscription.php">Vous inscrire</a>	<a href="connexion.php">Vous identifier</a>';
		
				echo'<p id="map">MAP</p>';
			}
		else{
				//$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
			//$rep = $bdd->query("select * from etablissement,preferer_type,preferer_ambiance,preferer_convives where ");  // requete qui acffiche les etablissement qui ont l'ambiance 
			
		while ($ligne = $rep ->fetch()) { // recuperations des infos sur les bars
			echo "<fieldset>"
			echo "<a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['map']."</a>\n";
			echo "<a href='etablissements.php?id-eta=".$ligne['id_eta']."'>".$ligne['nom']."</a>\n";
			echo "<a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['adresse']."</a>\n"
			echo "<a href='etablissements.php?id-eta=".$ligne['id-eta']."'>".$ligne['horaires']."</a>\n";
			echo "</fieldset>";
		}
		$rep ->closeCursor();
				echo'<a href="deconnexion.php"> Se déconnecter </a>';
		}
		?>
		
		
		<?php
			include("include/footer.php");
		?>
		
	</body>
	
</html>