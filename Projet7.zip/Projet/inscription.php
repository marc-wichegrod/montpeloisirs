<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		<p id="connexion">
			<a href="">Inscription</a> | 
			<a href="">Connexion</a> 
		</p>
		<?php
			include("include/header.php");
			include("include/nav.php");
			// $id=htmlspecialchars($_GET['id']);
			// $bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
		?>
		<form method="get" action="enregistrement.php">
	
		<fieldset> <!--Permet de faire l'encadré-->
			<legend>Qui êtes-vous ?</legend>
			<label for="sexe">Sexe : </label>
			<input type="radio" value="femme" name="sexe" <?php if (isset($_GET['sexe']) && $_GET['sexe'] == "femme") { echo "checked='true'"; } ?> /> Femme
			<input type="radio" value="homme" name="sexe" <?php if (isset($_GET['sexe']) && $_GET['sexe'] == "homme") { echo "checked='true'"; } ?> /> Homme
			<br/><br/>
			<label for="date_naissance">Date de naissance :</label>
			<input type="date" id="date_naissance">
			<span style="color: red;" id="erreur_date"></span>
		</fieldset>
		
		<fieldset>
			<legend>Informations de compte</legend>

			<label for="email">E-mail : </label>
			<input type="text" id="email" /> <span style="color: red;" id="erreur_email"></span> <br/><br/>
			<label for="pseudo">Pseudo : </label>
			<input type="text" id="pseudo" /> <br/><br/>
			<label for="mdp">Mot de passe : </label>
			<input type="text" id="mdp" /> <br/><br/>
			<label for="mdp_conf">Confirmation du mot de passe : </label>
			<input type="text" id="mdp_conf" /> <span style="color: red;" id="erreur_email"></span> 
		</fieldset>

		<fieldset> <!--probleme de jointure avec la base-->
			<legend>Vos sorties ?</legend>
			<label for="frequence">A quelle fréquence sortez-vous ?</label>
			<input type="radio" value="1" name="frequence"/> Tout le temps
			<input type="radio" value="2" name="frequence"/> Régulièrement
			<input type="radio" value="3" name="frequence"/> Rarement
			<br/><br/>
			<label>Avec qui aimez-vous sortir ?</label>
			<input type="radio" value="1" name="convives"/> En famille
			<input type="radio" value="2" name="convives" /> Entre amis
			<input type="radio" value="3" name="convives" /> Entre amoureux
			<br/><br/>
			<label>Quel(s) type(s) de lieu préférez-vous ?</label>
			<input type="radio" value="1" name="lieu"/> Bar
			<input type="radio" value="2" name="lieu" /> Café
			<input type="radio" value="3" name="lieu" /> Fast-food
			<input type="radio" value="5" name="lieu" /> Pub <br><br>
			<input type="radio" value="6" name="lieu" /> Restaurant
			<input type="radio" value="7" name="lieu" /> Cinéma
			<br/><br/>
			<label>Quel type d'ambiance préférez-vous ?</label>
			<input type="radio" value="1" name="ambiance" /> Electro
			<input type="radio" value="2" name="ambiance" /> Chic
			<input type="radio" value="3" name="ambiance" /> Dansante <br/><br/>
			<input type="radio" value="4" name="ambiance" /> Multiculturelle
			<input type="radio" value="5" name="ambiance" /> Rétro
			<br/><br/>
		</fieldset>
		<p>
			<input type="button" onclick="check()" value="Confirmer votre inscription">
		</p>
		
		
		<?php
			include("include/footer.php");
		?>
		

	<script type="text/javascript">
	function check() {
		var erreur = 0;

		var date = new Date(document.getElementById('date_naissance').value).toISOString();
		var today = new Date().toISOString();
		if (date > today) {
			document.getElementById('erreur_date').innerHTML = " Date incorrecte";
			erreur = 1;
		}
		else
			document.getElementById('erreur_date').innerHTML = "";

		if (document.getElementById('email').innerHTML != /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) {   ///// LA REGEX NE MARCHE PAS
			document.getElementById('erreur_email').innerHTML = " Adresse mail non valide";

		}
		else
			document.getElementById('erreur_email').innerHTML = "";
	}


	</script>

	</body>
	
</html>