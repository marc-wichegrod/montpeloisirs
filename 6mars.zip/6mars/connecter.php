<?php
session_start()
?>
<html>

	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet"href="styles/style.css"type="text/css"media="screen"/>
		<title>Verification connexion</title>
	</head>
		<body>
		<?php
		
		$bdd = new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8','root','root');
		$req = "select * where 'pseudo' ='".$_GET['pseudo']."' and 'mdp' = '".$_GET['mdp']."'";
		$rep = $bdd->query($req);
		$ligne = $req->fetch();
		
	
		if( $_GET['pseudo']=="" || $_GET['mdp']=="" || $_GET['pseudo'] != $ligne['pseudo']  || $_GET['mdp'] != $ligne['mdp']) {
			echo "<META http-equiv='refresh' content='1; URL=connexion.php'>";
		}
		else{

			$_SESSION['pseudo']='$_GET['pseudo']';
			$_SESSION['mdp']='$_GET['mdp']';
			echo "<META http-equiv='refresh' content='1; URL=index.php'>";
		}
		?>
		
		
		</body>
</html>