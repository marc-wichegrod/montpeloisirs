<html>
	<head>
	<meta charset="utf-8" />
	<title>Montpeloisirs</title>
	<link rel ="stylesheet" href="style/style.css"  type="text/css" media="screen"/>    
	</head>

	<body>
		
		<?php
			include("include/header.php"); 
			include("include/nav.php");
			//$id=htmlspecialchars($_GET['id']);
			//$bdd= new PDO('mysql:host=localhost:8889;dbname=montpeloisirs;charset=utf8', 'root', 'root'); 
		?>
		<form action="connecter.php" method="get" autocomplete="off">
	
		<fieldset>
			<legend> Connexion </legend>
			<tr>
		
			<td><label for="pseudo">Pseudo :</label></td>
			<td><input type="text" name="pseudo" rows="1"  cols="30" ></input></td>
			</tr><br>
			<tr>
			<td><label for="mot de passe">Mot de passe :</label></td>
			<td><input type="password" name="mot de passe" value="" ></input></td>
			</tr>
			<br>
			<input type="submit" value="Validation"/> 
			</br>
			<br> <a href="changerPass.php"> Mot de passe oublié? </a></br>
			<a href="index.php"> retour </a>
		</fieldset>
		<?php
			include("include/footer.php");
		?>
	</body>
	
</html>