<div id="menu">

	<ul>
		<li><a href="">Bar<a></li>
		<li><a href="">Restaurant<a></li> 
		<li><a href="">Cinéma<a></li>
		<li><a href="questionnaire.php">Recherche personnalisée<a></li> 
		<form action="rechercher.php" method="GET" autocomplete="off">
		<input type="text" name="nom" placeholder="Rechercher " />
		<input type="image" width=30px src="images/loupe.png" name="mon_image" onclick="submit(rechercher.php)"/></form>
	</ul>	
</div>
