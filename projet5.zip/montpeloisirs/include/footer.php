<div id="footer">
	<ul>
		<li>34 Route de Mende, 34090 Montpellier</li>
		<li>Tel : 06 22 73 71 48</li>
		<li>contact@montpeloisirs.fr</li>
		<div class="logo">
			<li><a title="Facebook" onclick="window.open('https://www.facebook.com/villemontpellier34/');return false;"><img src="images/facebook.png" alt="Y"></a></li>
			<li><a title="Twitter" onclick="window.open('https://twitter.com/montpellier_');return false;"><img src="images/twitter.png" alt="Y"></a></li>
			<li><a title="Instagram" onclick="window.open('https://www.instagram.com/villedemontpellier/');return false;"><img src="images/instagram.png" width="20" alt="Y"></a></li>
			<li><a title="Youtube" onclick="window.open('https://www.youtube.com/?hl=fr&gl=FR');return false;"><img src="images/youtube.png" alt="Y"></a></li>
			<li><a title="Github" onclick="window.open('https://github.com/mwichegr/montpeloisirs');return false;"><img src="images/github.png" width="20 alt="Y"></a></li>
		</div>
	</ul>
</div>	
	